import os
import requests
from dotenv import load_dotenv

# Load .env variables
load_dotenv()

def test_connection():
    jira_domain = os.getenv("JIRA_DOMAIN")
    token = os.getenv("JIRA_API_TOKEN")

    if not jira_domain or not token:
        print("? Error: Missing JIRA_DOMAIN or JIRA_API_TOKEN in .env file.")
        return

    # Test Endpoint: 'Myself' (The most reliable way to verify identity)
    # Note: Jira Data Center usually uses /rest/api/2
    url = f"{jira_domain}/rest/api/2/myself"

    headers = {
        "Authorization": f"Bearer {token}",  # Use Bearer Token for PAT
        "Accept": "application/json"
    }

    print(f"Testing connection to: {url} ...")

    try:
        # Set a timeout of 10 seconds
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            user_data = response.json()
            print("\n? Authentication Successful!")
            print(f"Username:     {user_data.get('name')}")
            print(f"Display Name: {user_data.get('displayName')}")
            print(f"Email:        {user_data.get('emailAddress')}")
            print("------------------------------------------------")
            print("You are ready to run the ETL service.")
        else:
            print(f"\n? Authentication Failed (Status: {response.status_code})")
            print("Response Snippet:", response.text[:200])
            print("\nTroubleshooting:")
            print(" - 401: Invalid Token. Check your JIRA_API_TOKEN.")
            print(" - 404: Invalid URL. Check your JIRA_DOMAIN.")

    except Exception as e:
        print(f"\n? Connection Error: {e}")

if __name__ == "__main__":
    test_connection()
